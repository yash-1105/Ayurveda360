import React from 'react';
import { Leaf, Heart, Brain, Users, ArrowRight } from 'lucide-react';

function FeatureCard({ icon: Icon, title, description }: { icon: React.ElementType; title: string; description: string }) {
  return (
    <div className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-shadow">
      <div className="h-12 w-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
        <Icon className="h-6 w-6 text-green-600" />
      </div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
}

function Testimonial({ name, image, quote }: { name: string; image: string; quote: string }) {
  return (
    <div className="bg-white rounded-xl p-6 shadow-lg">
      <div className="flex items-center mb-4">
        <img src={image} alt={name} className="w-12 h-12 rounded-full object-cover" />
        <h4 className="ml-3 font-semibold">{name}</h4>
      </div>
      <p className="text-gray-600 italic">"{quote}"</p>
    </div>
  );
}

export default function Home() {
  return (
    <div>
      {/* Hero Section */}
      <div 
        className="relative h-screen flex items-center justify-center bg-cover bg-center -mt-16"
        style={{
          backgroundImage: 'linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url("https://images.unsplash.com/photo-1611071536600-685c6fe4e31d?auto=format&fit=crop&q=80")'
        }}
      >
        <div className="text-center text-white px-4">
          <h1 className="text-5xl md:text-6xl font-bold mb-6">
            Unlock Your Unique Ayurvedic Wellness Journey
          </h1>
          <p className="text-xl md:text-2xl mb-8 max-w-2xl mx-auto">
            Discover personalized ancient wisdom for modern well-being through AI-powered Ayurvedic guidance
          </p>
          <button className="bg-green-600 hover:bg-green-700 text-white font-semibold py-3 px-8 rounded-full text-lg flex items-center mx-auto transition-colors">
            Take Your Dosha Test
            <ArrowRight className="ml-2 h-5 w-5" />
          </button>
        </div>
      </div>

      {/* Features Section */}
      <div className="max-w-7xl mx-auto px-4 py-20">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-16">
          Your Path to Holistic Wellness
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <FeatureCard
            icon={Leaf}
            title="Personalized Recommendations"
            description="Get tailored Ayurvedic insights based on your unique dosha composition"
          />
          <FeatureCard
            icon={Heart}
            title="Wellness Marketplace"
            description="Discover authentic Ayurvedic products curated for your well-being"
          />
          <FeatureCard
            icon={Brain}
            title="AI-Powered Insights"
            description="Advanced analytics for personalized health recommendations"
          />
          <FeatureCard
            icon={Users}
            title="Supportive Community"
            description="Connect with like-minded individuals on their wellness journey"
          />
        </div>
      </div>

      {/* Testimonials Section */}
      <div className="bg-green-50 py-20">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-16">
            Transformation Stories
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Testimonial
              name="Sarah Johnson"
              image="https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&q=80"
              quote="The personalized Ayurvedic recommendations completely transformed my daily routine and energy levels."
            />
            <Testimonial
              name="Michael Chen"
              image="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80"
              quote="The AI-powered insights helped me understand my body better than ever before."
            />
            <Testimonial
              name="Priya Patel"
              image="https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80"
              quote="Finding a community of like-minded people has made my wellness journey so much more enjoyable."
            />
          </div>
        </div>
      </div>
    </div>
  );
}