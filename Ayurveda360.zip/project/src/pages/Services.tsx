import React from 'react';
import { Brain, Users, ShieldCheck, Sparkles } from 'lucide-react';

export default function Services() {
  const services = [
    {
      icon: Brain,
      title: "AI-Powered Dosha Analysis",
      description: "Get a comprehensive analysis of your mind-body constitution through our advanced AI system.",
      features: [
        "Personalized dosha assessment",
        "Detailed health insights",
        "Custom wellness recommendations",
        "Regular progress tracking"
      ],
      price: "₹3,999/month"
    },
    {
      icon: Users,
      title: "Expert Consultations",
      description: "Connect with certified Ayurvedic practitioners for personalized guidance.",
      features: [
        "One-on-one video sessions",
        "Written recommendations",
        "Follow-up support",
        "Prescription management"
      ],
      price: "₹7,999/session"
    },
    {
      icon: ShieldCheck,
      title: "Wellness Programs",
      description: "Structured programs designed to address specific health concerns.",
      features: [
        "12-week structured plan",
        "Weekly check-ins",
        "Community support",
        "Progress monitoring"
      ],
      price: "₹15,999/program"
    },
    {
      icon: Sparkles,
      title: "Premium Membership",
      description: "All-inclusive access to our complete range of services.",
      features: [
        "Unlimited AI analysis",
        "Monthly expert consultation",
        "Access to all programs",
        "Priority support"
      ],
      price: "₹11,999/month"
    }
  ];

  return (
    <div className="py-16">
      <div className="max-w-7xl mx-auto px-4">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">Our Services</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Comprehensive Ayurvedic wellness solutions tailored to your unique needs
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 gap-8 mb-20">
          {services.map((service) => {
            const Icon = service.icon;
            return (
              <div key={service.title} className="bg-white rounded-xl p-8 shadow-lg">
                <div className="h-12 w-12 bg-green-100 rounded-lg flex items-center justify-center mb-6">
                  <Icon className="h-6 w-6 text-green-600" />
                </div>
                <h2 className="text-2xl font-bold mb-4">{service.title}</h2>
                <p className="text-gray-600 mb-6">{service.description}</p>
                <ul className="space-y-3 mb-8">
                  {service.features.map((feature) => (
                    <li key={feature} className="flex items-center text-gray-600">
                      <span className="h-2 w-2 bg-green-600 rounded-full mr-3"></span>
                      {feature}
                    </li>
                  ))}
                </ul>
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-bold text-green-600">{service.price}</span>
                  <button className="bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-6 rounded-full transition-colors">
                    Get Started
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}