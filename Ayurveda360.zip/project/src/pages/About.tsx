import React from 'react';
import { Leaf, Heart } from 'lucide-react';

export default function About() {
  return (
    <div className="py-16">
      <div className="max-w-7xl mx-auto px-4">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">About Ayurveda 360</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Bridging ancient wisdom with modern technology to provide personalized wellness solutions.
          </p>
        </div>

        {/* Mission & Vision */}
        <div className="grid md:grid-cols-2 gap-12 mb-20">
          <div className="bg-white rounded-xl p-8 shadow-lg">
            <div className="h-12 w-12 bg-green-100 rounded-lg flex items-center justify-center mb-6">
              <Leaf className="h-6 w-6 text-green-600" />
            </div>
            <h2 className="text-2xl font-bold mb-4">Our Mission</h2>
            <p className="text-gray-600">
              To make the transformative power of Ayurveda accessible to everyone through innovative technology and personalized guidance, helping individuals achieve optimal health and well-being.
            </p>
          </div>
          <div className="bg-white rounded-xl p-8 shadow-lg">
            <div className="h-12 w-12 bg-green-100 rounded-lg flex items-center justify-center mb-6">
              <Heart className="h-6 w-6 text-green-600" />
            </div>
            <h2 className="text-2xl font-bold mb-4">Our Vision</h2>
            <p className="text-gray-600">
              To create a world where everyone can access and benefit from personalized Ayurvedic wisdom, leading to healthier, more balanced lives through the perfect blend of ancient knowledge and modern science.
            </p>
          </div>
        </div>

        {/* Team Section */}
        <div className="mb-20">
          <h2 className="text-3xl font-bold text-center mb-12">Our Team</h2>
          <div className="grid md:grid-cols-4 gap-8">
            {[
              {
                name: "Sumukh Chhabra",
                role: "CEO",
                description: "Leading our vision for accessible Ayurvedic wellness"
              },
              {
                name: "Yash Padam",
                role: "CTO",
                description: "Driving innovation in wellness technology"
              },
              {
                name: "Satvik Sharma",
                role: "Chief Management Officer",
                description: "Ensuring operational excellence and growth"
              },
              {
                name: "Vranch Sinha",
                role: "Chief of Operations",
                description: "Optimizing service delivery and user experience"
              }
            ].map((member) => (
              <div key={member.name} className="bg-white rounded-xl p-6 shadow-lg text-center">
                <div className="h-16 w-16 bg-green-100 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <span className="text-2xl font-bold text-green-600">
                    {member.name.charAt(0)}
                  </span>
                </div>
                <h3 className="text-xl font-semibold mb-1">{member.name}</h3>
                <p className="text-green-600 mb-2">{member.role}</p>
                <p className="text-gray-600">{member.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}