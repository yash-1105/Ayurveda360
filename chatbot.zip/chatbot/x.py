import os
import faiss
from dotenv import load_dotenv
from typing import List
from sentence_transformers import SentenceTransformer
from openai import OpenAI
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np

# Load OpenRouter API key
load_dotenv()
OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY")

# OpenRouter-compatible OpenAI client
client = OpenAI(
    api_key=OPENROUTER_API_KEY,
    base_url="https://openrouter.ai/api/v1"
)

# Optional: silence HuggingFace tokenizers warning
os.environ["TOKENIZERS_PARALLELISM"] = "false"

# Load embedding model
embedder = SentenceTransformer("all-MiniLM-L6-v2")

# Path to knowledge base
KNOWLEDGE_FILE = "/Users/sumukhchhabra/Desktop/Codes /DTI/Ayurveda360/chatbot/ayurveda_knowledge.txt"

if not os.path.exists(KNOWLEDGE_FILE):
    print(f"❌ File not found: {KNOWLEDGE_FILE}")
    exit(1)

with open(KNOWLEDGE_FILE, "r") as file:
    paragraphs = [p.strip() for p in file.read().split("\n") if p.strip()]

if not paragraphs:
    print("❌ No content found in the Ayurvedic knowledge file.")
    exit(1)

print(f"✅ Loaded {len(paragraphs)} Ayurvedic entries.")

# Create FAISS index
corpus_embeddings = embedder.encode(paragraphs)
index = faiss.IndexFlatL2(corpus_embeddings.shape[1])
index.add(corpus_embeddings)

# Context retrieval
def retrieve_context(query: str, top_k: int = 3, min_similarity: float = 0.6) -> List[str]:
    query_embedding = embedder.encode([query])
    distances, indices = index.search(query_embedding, top_k)

    filtered = []
    for idx in indices[0]:
        paragraph = paragraphs[idx]
        para_embedding = embedder.encode([paragraph])
        sim = cosine_similarity([query_embedding[0]], [para_embedding[0]])[0][0]
        if sim >= min_similarity:
            filtered.append(paragraph)
    return filtered

# Answer generation via OpenRouter
def generate_answer(query: str):
    greetings = ["hi", "hello", "hey", "namaste"]
    query_clean = query.strip().lower()

    if any(greet in query_clean for greet in greetings):
        return "Namaste 🙏 How can I assist you with Ayurvedic knowledge today?"

    context = retrieve_context(query)

    system_prompt = (
        "You are an Ayurvedic assistant. Respond clearly and concisely to the user's question. "
        "Use the context only if it's helpful. DO NOT include extra instructions, test cases, or repeat the question. "
        "ONLY return the direct answer."
    )

    response = client.chat.completions.create(
        model="mistralai/mixtral-8x7b",
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": f"{query}\n\nContext:\n" + "\n".join(context)}
        ],
        temperature=0.5,
        max_tokens=150
    )

    answer = response.choices[0].message.content.strip()

    # Final cleanup — remove anything that doesn't look like a plain answer
    for line in answer.splitlines():
        if line.strip() and not any(prefix in line.lower() for prefix in ["user", "question", "answer", "test case"]):
            return line.strip()

    # Fallback: return the full cleaned response
    return answer

# CLI chatbot loop
if __name__ == "__main__":
    print("🧘 Welcome to the Ayurvedic Chatbot (type 'exit' to quit)")
    while True:
        user_input = input("\nYou: ")
        if user_input.lower() == "exit":
            print("👋 Goodbye!")
            break
        try:
            answer = generate_answer(user_input)
            print(f"Bot: {answer}")
        except Exception as e:
            print(f"❌ Error: {e}")
